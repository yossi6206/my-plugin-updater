<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Dependency Injection Configuration.
 *
 * This file registers definitions for PHP-DI used by Elementor.
 *
 * @since 3.25.0
 */

return [];
